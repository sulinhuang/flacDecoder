
declare module 'gulp-jsdoc3';
declare module 'fancy-log';
